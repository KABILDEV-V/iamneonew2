// app.js
angular.module('myApp', [])
  .controller('UserController', ['$scope', '$http', function($scope, $http) {
    $scope.users = [];

    // Get all users
    $scope.getUsers = function() {
      $http.get('/users')
        .then(function(response) {
          $scope.users = response.data;
        })
        .catch(function(error) {
          console.error(error);
        });
    };

    // Create a new user
    $scope.createUser = function(user) {
      $http.post('/users', user)
        .then(function(response) {
          $scope.users.push(response.data);
          $scope.newUser = {}; // Clear the form
        })
        .catch(function(error) {
          console.error(error);
        });
    };

    // Delete a user
    $scope.deleteUser = function(user) {
      $http.delete('/users/' + user.id)
        .then(function(response) {
          var index = $scope.users.indexOf(user);
          if (index !== -1) {
            $scope.users.splice(index, 1);
          }
        })
        .catch(function(error) {
          console.error(error);
        });
    };

    // Fetch initial user data
    $scope.getUsers();
  }]);
